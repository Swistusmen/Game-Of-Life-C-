#include <iostream>
#include "Game.hpp"
#include "Logic.hpp"


int main()
{
    Game gra;
    gra.Run();


    return 0;
}
