#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <vector>
#include <map>
#include <memory>
#include "Logic.hpp"
#include <boost/filesystem.hpp>
#include <fstream>
#include <sstream>
#include <utility>


void Playground::Return_Previous_State()
{
    if(wektor1.empty()==0)
    {
        wektor1.clear();
    }
    plansza.Zero();

    it2=lista.rbegin();

    while(it2->ret_x()!=100)
    {
        int x=it2->ret_x();
        int y=it2->ret_y();
        lista.pop_back();
        if(plansza.IsZero(x,y)==1)
        {
            plansza.Set_value(x,y,1);
            Object<int> a{x,y};
            wektor1.push_back(a);
        }

        it2++;
    }
    it2=lista.rend();
    std::cout<<"AAAA:"<<it2->ret_x()<<std::endl;
    lista.pop_front();
    std::cout<<"ROZMIAR LISTY "<<lista.size()<<std::endl;
}

void Playground::Hunting()
{
    lista.push_back(Object<int> {100,0});
    for (; wektor1.empty()==0; wektor1.pop_back())
    {
        int x=wektor1.back().ret_x();
        int y=wektor1.back().ret_y();
        lista.push_back(Object<int> {x,y});
        HuntAndKill(x,y);//przeszukuje w tablicy otoczenie
    }
    return;
}

void Playground::regenerate()
{
    plansza.Zero();
    for (; wektor2.empty()==0;) //stworzyc obiekt i umiescic w wektorze, przedstawic w tablicy
    {
        int x=wektor2.back().ret_x();
        int y=wektor2.back().ret_y();
        wektor2.erase(wektor2.begin()+wektor2.size());//odpowiednik wektor2.end()
        if(plansza.IsZero(x,y)==1)
        {
            plansza.Set_value(x,y,1);
            Object<int> a{x,y};
            wektor1.push_back(a);
        }
    }
    if(wektor1.size()==0)
    {
        std::cout<<"Smierc populacji\n";
        exit(0);
    }
    return;
}

void Playground::update(sf::RenderWindow& appwindow,int t)
{
    std::vector<Object<int>>::iterator it;
    if((VectorSwitcher==0)||(t==2)){
    for(it=wektor1.begin();it!=wektor1.end();it++){
        Cell.setPosition(RAMKA+(it->ret_x()+SRODKOWANIE)*SKALAR,(it->ret_y()+SRODKOWANIE)*SKALAR);
        appwindow.draw(Cell);
    }}
    else{
    for(it=wektor2.begin();it!=wektor2.end();it++){
        Cell.setPosition(RAMKA+(it->ret_x()+SRODKOWANIE)*SKALAR,RAMKA+(it->ret_y()+SRODKOWANIE)*SKALAR);
        appwindow.draw(Cell);
    }}
}

void Playground::Decompress(int w,int h,int rozm,std::string &napis)
{
    int indeks_w {10},indeks_h {10};// indeksy komorek, ustawiamy na 10 bo tak, to ustawienie na planszy, 10,10 to 0,0
    bool number {0}; // CPPPPPPPPPPPPPPPPP 11
    std::vector<int> liczba;
    for(int i=0; i<static_cast<int>(napis.length()),napis[i]!=33; i++)//przesuwaj sie po elementach lancucha
    {
   if((napis[i]==48)||(napis[i]==49)||(napis[i]==50)||(napis[i]==51)||(napis[i]==52)||(napis[i]==53)||(napis[i]==54)||
                (napis[i]==55)||(napis[i]==56)||(napis[i]==57))//jesli jest cyfra, wlacz flage liczby, wrzuc na wektor
        {
            number=1;
            liczba.push_back(napis[i]-48);
        }
        else{//jesli nie jest liczba to ustaw odpowiednia iloœæ komorek w wektorze
                int suma {0};
             if(number==1)
            {
                for(int i=1; liczba.empty()==0; i=i*10,liczba.erase(liczba.begin()+liczba.size()-1))
                    suma+=liczba.back()*i;
            }//ustal sume, ilu komorek dotyczy operacja
            else suma=1;
           for(int g=0;g<suma;indeks_h++,g++)//ustaw na w wetkorze te liczby
           {
               if(napis[i]==111)
               {
                            Object<int> obj{indeks_w,indeks_h};
                            wektor1.push_back(obj);
                            plansza.Set_value(indeks_w,indeks_h,true);//TRZEBA ZMIENIC
               }
            }

            if(indeks_h==w+11)
            {
                indeks_h=10;
                indeks_w++;
            }
            number=0;
           }
        }
}

int Playground::FindInt(std::string & napis)
{
    std::vector<int> liczby;
    for(int i=0;i<static_cast<int>(napis.length());i++)
        if((napis[i]==48)||(napis[i]==49)||(napis[i]==50)||(napis[i]==51)||(napis[i]==52)||(napis[i]==53)||(napis[i]==54)||
        (napis[i]==55)||(napis[i]==56)||(napis[i]==57))
                liczby.push_back(napis[i]-48);
        //ponizej wziête z funkcji gimme z gameflife 08
        int suma=0;
    for(int i=1; liczby.empty()==0; i=i*10,liczby.erase(liczby.begin()+liczby.size()-1))
        suma+=liczby.back()*i;
    return suma;
}

void Playground::LoadFromFileAndInitiate()
{
        std::fstream plik;
        namespace fs=boost::filesystem;
        for(auto& p: fs::recursive_directory_iterator("RLE"))////// CPP 11
        std::cout << p << '\n';
        std::cout<<"Podaj nazwe pliku ktory chcesz otworzyc: ";
        std::string name;
        std::cin>>name;
        plik.open(name,std::ios::in);
        if(!plik.is_open())
        {
            std::cerr<<"Nie udalo sie otworzyc pliku do zapisu\n";
            exit(0);
        }
        int w,h,rozm=0;
        std::string widd,heigg,mainstream;

    if (!(plik >> widd >> heigg >> mainstream)) {
    std::cerr << "file badly formatted";
    }

        plik.close();
        w=FindInt(widd);
        h=FindInt(heigg);
        rozm=60;
        plansza.create(rozm);
        Decompress(w,h,rozm, mainstream);
}

void Playground::EraseTheVector()
{
    if(VectorSwitcher==0)
    wektor1.erase(wektor1.begin(),wektor1.end());
    else
    wektor2.erase(wektor2.begin(),wektor2.end());

}

void Playground::HuntAndKill(int x,int y)
{
    int h,w;
    if(y>0)
        h=y-1;
    else if(y==0)
        h=plansza.Get_size()-1;
    if(x>0)
        w=x-1;
    else
        w=x;
    int maxw=x+2;

    for(; ((w<maxw)&&(w<plansza.Get_size())); w++)
    {
        for(int i=0; i<3 ; i++)
        {
            if(1==plansza.Sniff(w,h))
            {
                Object<int> a (w,h);//zmiana ze zwykłego obiektu a

                if(VectorSwitcher==0)
                wektor2.push_back(a);
                else
                    wektor1.push_back(a);
                }
            if (h==plansza.Get_size()-1)
                h=0;
            else
                h++;
            }

        if(y>0)
            h=y-1;
        else if(y==0)
            h=plansza.Get_size()-1;
    }
    return;
    }

Playground::Playground():plansza()
{
    AliveCell.loadFromFile("AliveCell.jpg");
    Cell.setTexture(AliveCell);
    VectorSwitcher=0;
}

DoubleTab::DoubleTab()
{
    SizeOfPlayground=0;
    wsk=nullptr;//// CPP 11
}

void DoubleTab::Zero()
{
    for (int i=0;i<SizeOfPlayground;i++)
        for(int j=0;j<SizeOfPlayground;j++)
            Set_value(i,j,0);
}

void DoubleTab::create(int rozmiar)
{
    SizeOfPlayground=rozmiar;
        wsk=new bool*[rozmiar];
    for(int j=0;j<rozmiar;j++)
        wsk[j]=new bool[rozmiar];
        Zero();
}

bool DoubleTab::IsZero(int x,int y)
{
    if (wsk[x][y]==1)
        return false;
    return true;
}

void DoubleTab::Set_value(int x,int y, bool val)
{
    wsk[x][y]=val;
}

bool DoubleTab::Sniff(int x,int y)
{
    int xx,yy;

        auto lambda=[](int a, int b){/////////////// CCCCCCCC+++ 11 lambda+ auto
         int c;
         a-1>=0? c= a-1: c=b-1;
         return c;
         };

         yy=lambda(y,this->Get_size());
         xx=lambda(x,x+1);

   /* if(x-1>=0)
        xx=x-1;
    else
        xx=x;*/


    int licznik=0,bufy=yy;
    int maxx=x+2;
    for(; ((xx<maxx)&&(xx<Get_size())); xx++)
    {
        for(int i=0; i<3; i++)
        {
            if(0==IsZero(xx,yy))
            {
                licznik++;
            }
            if(yy==Get_size()-1)
                yy=0;
            else
                yy++;
        }
        yy=bufy;
    }
    if((0==IsZero(x,y))&&((licznik==3)||(licznik==4)))
        return 1;
    else if((1==IsZero(x,y))&&(licznik==3))
        return 1;
    else
        return 0;
}

