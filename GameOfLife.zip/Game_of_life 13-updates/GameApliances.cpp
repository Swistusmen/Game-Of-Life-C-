#include <iostream>
#include <SFML/Graphics.hpp>
#include <list>
#include "GameApliances.hpp"
#include <string>

void MenuPanel::draw(sf::RenderWindow& appwindow)
{
    taski[0].draw(appwindow);
    taski[1].draw(appwindow);
}

int MenuPanel::Run(sf::RenderWindow& appwindow)
{
        int i=0;
while(i==0){
    appwindow.clear();
    draw(appwindow);
    ProcessEvents(appwindow);
    i=WhatToDo();
}
}

int MenuPanel::HandleFPS()
{
    return 0;
}

int MenuPanel::WhatToDo()
{
    switch(Tryb)
    {
    case MenuTribe::Nic:
        {
            return 0;
        }break;
    case MenuTribe::Powrot:
        {
            return -1;
        }
    case MenuTribe::FramePerSeconds:
        {
            return HandleFPS();
        }break;
    }
}

void MenuPanel::ProcessEvents(sf::RenderWindow& appwindow)
{
        while(appwindow.pollEvent(zdarzenie))
        {
            if(zdarzenie.type==sf::Event::Closed)
            {
                appwindow.close();
                exit(0);
            }
            if(zdarzenie.type==sf::Event::MouseButtonPressed)
            {
                Tryb=IsClicked(zdarzenie.mouseButton.x,zdarzenie.mouseButton.y);
            }
        }
}

MenuTribe MenuPanel::IsClicked(int x,int y)
{
    ButtonActions bufor=ButtonActions::Nothing;
    for(int i=0;i<2;i++)
    {
        bufor=taski[i].IsClicked(x,y);
        if(ButtonActions::Nothing!=bufor)
            {
                switch(bufor)
                {
                case ButtonActions::Play:
                    {
                        return MenuTribe::Powrot;
                    }break;
                case ButtonActions::Other:
                    {
                        return MenuTribe::FramePerSeconds;
                    }break;
                }
            }
    }
    return MenuTribe::Nic;
}

MenuPanel::MenuPanel()
{
    std::string buf="FPS setter";
    taski[0].FullFill(600,400,buf,ButtonActions::Other);
    buf="Powrot";
    taski[1].FullFill(600,1200,buf,ButtonActions::Play);
}

ButtonActions Taskbar::IsClicked(int x, int y)
{
    ButtonActions buffer {ButtonActions::Nothing};
    if((y>=1520)&&(y<=1720))
    {
        for(int i=0;i<4;i++){
            if ((200+(400*i)<=x)&&(200+400*(i+1)>x)){
            return taski[i].IsClicked(x,y);}
        }
    }
    else
    {
        std::cout<<"Niccccccc\n";
        return ButtonActions::Nothing;
    }
}

ButtonActions Button::IsClicked(int x,int y)
{
    return action;
}

void Taskbar::draw(sf::RenderWindow& appwindow)
{
    for(int i=0;i<4;i++)
        taski[i].draw(appwindow);
}

Taskbar::Taskbar()
{
    std::string napis="Play";
    taski[0].FullFill(200,1520,napis,ButtonActions::Play);
    napis="StepBack";
    taski [1].FullFill(600,1520,napis,ButtonActions::Back);
    napis="StepForward";
    taski [2].FullFill(1000,1520,napis,ButtonActions::Forward);
    napis="Other";
    taski [3].FullFill(1400,1520,napis,ButtonActions::Other);
}

void Button::FullFill(int x,int y,std::string & tresc,ButtonActions akcja)
{
    duszek.setPosition(x,y);
    napis.setPosition(x+150,y+80);
    napis.setString(tresc);
    action=akcja;
}

void Button::draw(sf::RenderWindow& appwindow)
{
    appwindow.draw(duszek);
    appwindow.draw(napis);
}

Button::Button()
{
    teksturka.loadFromFile("button.jpg");
    duszek.setTexture(teksturka);
    tekscior.loadFromFile("font.ttf");
    napis.setFont(tekscior);
    action=ButtonActions::Other;
}


