#ifndef GAMEAPLIANCES_HPP_INCLUDED
#define GAMEAPLIANCES_HPP_INCLUDED

#endif // GAMEAPLIANCES_HPP_INCLUDED
#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <list>

enum ButtonActions {Play,Back,Forward,Other,Nothing};

enum MenuTribe {Powrot, Nic, FramePerSeconds};

class Button{
public:
    void draw(sf::RenderWindow&);
    void FullFill(int,int,std::string &,ButtonActions );//wypelnia tekst i wsp�rz�dne
    Button();
    ButtonActions IsClicked(int,int);
private:
    sf::Sprite duszek;
    sf::Font tekscior;
    sf::Texture teksturka;
    sf::Text napis;
    ButtonActions action;
};

class MenuPanel{
public:
    MenuPanel();

    int Run(sf::RenderWindow&);

private:
    void draw(sf::RenderWindow&);
    void ProcessEvents(sf::RenderWindow&);
    MenuTribe IsClicked(int, int);
    MenuTribe Tryb=MenuTribe::Nic;
    int WhatToDo();
    int HandleFPS();

    Button taski[2];
    sf::Event zdarzenie;
};

class Taskbar{
public:
    Taskbar();
    void draw(sf::RenderWindow &);
    ButtonActions IsClicked(int, int);
    void update(int);
private:
    Button taski[4];
};



