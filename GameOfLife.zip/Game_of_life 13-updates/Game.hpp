#ifndef GAME_HPP_INCLUDED
#define GAME_HPP_INCLUDED




#endif // GAME_HPP_INCLUDED
#pragma once
#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include "Logic.hpp"
#include "GameApliances.hpp"


class Game{
public:
    Game();
    void Run();

    enum GameTribes{Play,Pause,Stepback,StepForward,Nothing,Menu,Closing,Silence};

private:
    void render();
    void ProcessEvents();//pobiera zdarzenie
    void WhatToDo();//reaguje na zdarzenie
    GameTribes HandleButton(int, int);

    Playground rozgrywka;

    sf::RenderWindow appwindow;
    GameTribes Tryb;
    Taskbar PasekZadan;
    //MenuPanel MainMenu;
    float FPSLimitter=20.f;
    void ChangeFPSLimit();

    sf::Time DeltaTime= sf::seconds(1.f/FPSLimitter);
};
