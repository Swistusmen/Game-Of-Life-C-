#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include "Game.hpp"
#include "Logic.hpp"
#include "GameApliances.hpp"

void Game::Run()
{
    if(Tryb!=Game::Silence)
    {
        std::cout<<"Blad inicjalizacji!\n";
        exit(EXIT_FAILURE);
    }
    rozgrywka.LoadFromFileAndInitiate();

    appwindow.create(sf::VideoMode(2000,1800,32),"okno");
    Tryb=GameTribes::Play;

    sf::Clock timer;
    sf::Time TimeSinceLastUpdate;
    //sf::Time DeltaTime= sf::seconds(1.f/FPSLimitter);

    sf::Clock timer2;
    int licznik=0;
    //std::cout<<sizeof(Object<int>)<<" "<<sizeof(char)<<std::endl;

    while(appwindow.isOpen())
    {

        ProcessEvents();//ustala tryb gry

        if(Tryb!=GameTribes::Pause)
        {
            if(timer2.getElapsedTime()>=sf::seconds(1.f))//segment wyświetla FPS
            {
                timer2.restart();
                std::cout<<licznik<<std::endl;
                licznik=0;
            }
            TimeSinceLastUpdate+=timer.restart();//segmetn poniżej wykonuje operacje w określonych odstępach czasu
            if(TimeSinceLastUpdate> DeltaTime)
            {
                TimeSinceLastUpdate-=DeltaTime;
                rozgrywka.update(appwindow,Tryb);
                PasekZadan.draw(appwindow);
                appwindow.display();
                appwindow.clear();
                if(Tryb!=GameTribes::Stepback)
                {
                rozgrywka.Hunting();
                rozgrywka.regenerate();
                }
                else{
                rozgrywka.Return_Previous_State();

                }
                licznik++;
            }
        }

        WhatToDo();   //pierwotne po³o¿enie funkcji what to do
    }
}

void Game::render()
{
    appwindow.display();
}

void Game::WhatToDo()
{
    //dodac rozne mozliwe reakcje
    if(Tryb==GameTribes::Closing)
    {
        appwindow.close();
        exit(0);
    }
    else if (Tryb==GameTribes::StepForward)
    {
        Tryb=GameTribes::Pause;
        std::cout<<"WTD: Zmiana trybu z StepForward na Pause\n";
    }
    else if (Tryb==GameTribes::Menu)
    {
        std::cout<<"Przypadek obslugujacy Menu\n";
        ChangeFPSLimit();
    }
    else if (Tryb==GameTribes::Stepback)
    {
        Tryb=GameTribes::Pause;
        std::cout<<"Zmiana z StepBack na Pause\n";
    }
    return;
}

void Game::ChangeFPSLimit()
{
    float limit {10};
    float suma {0};
    sf::Event evencik;
    while(appwindow.waitEvent(evencik))
    {
        std::cout<<"Jestes w funkcji obslugujacej menu i fps setter\n";
        if(evencik.type==sf::Event::KeyPressed)
        {
            switch(evencik.key.code)
            {
            case sf::Keyboard::Num0:
            {
                limit/=10;
            }
            break;
            case sf::Keyboard::Num1:
            {
                suma+=limit*1;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num2:
            {
                suma+=limit*2;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num3:
            {
                suma+=limit*3;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num4:
            {
                suma+=limit*4;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num5:
            {
                suma+=limit*5;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num6:
            {
                suma+=limit*6;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num7:
            {
                suma+=limit*7;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num8:
            {
                suma+=limit*8;
                limit/=10;
            }
            break;
            case sf::Keyboard::Num9:
            {
                suma+=limit*9;
                limit/=10;
            }
            break;
            default:
            {
                suma+=0;
            }
            break;
            }
        }
        if(limit<1)
            break;
    }
    //FPSLimitter=suma;
    DeltaTime=sf::seconds(1.f/suma);
    Tryb=GameTribes::Pause;
    //break;
    //}
}

void Game::ProcessEvents()
{
    sf::Event zdarzenie;
    while(appwindow.pollEvent(zdarzenie))
    {
        if(zdarzenie.type==sf::Event::Closed)
        {
            Tryb=GameTribes::Closing;
        }
        if(zdarzenie.type==sf::Event::MouseButtonPressed)
        {
            Tryb=HandleButton(zdarzenie.mouseButton.x,zdarzenie.mouseButton.y);
        }
    }
}

Game::GameTribes Game::HandleButton(int x,int y)
{
    //dodac opcje reagowania zaleznie od wcisnietego przycisku
    std::cout<<"HB zmiana trybu z "<<"("<<Tryb<<")"<<" na : ";
    switch(PasekZadan.IsClicked(x,y))
    {
/*case ButtonActions::Nothing:*/ case ButtonActions::Back:
    {
        std::cout<<"StepBack\n";
        return GameTribes::Stepback;
    }break;
    case ButtonActions::Other:
    {
        std::cout<<"Menu\n";
        return GameTribes::Menu;
    }
    break;
    case ButtonActions::Play:
    {
        if(Tryb==GameTribes::Pause)
        {
             std::cout<<"Play\n";
            return GameTribes::Play;
        }
        else
        {
             std::cout<<"Pause\n";
            return GameTribes::Pause;
        }
    }break;
    case ButtonActions::Forward:
    {
         std::cout<<"StepForward\n";
        return GameTribes::StepForward;
    }break;
    case ButtonActions::Nothing:
        {
            std::cout<<"HB Nothing\n";
            return Tryb;
        }break;
    default:
        {
            std::cout<<"Nic\n";
            return Tryb;
        }
    }
    //std::cout<<"HB Nie dokonano zmiany"<<std::endl;//Niepotrzebny fragment po dodaniu obsugi Nothing
    //return GameTribes::Play;
}


Game::Game():rozgrywka()
{
    Tryb=Game::Silence;
}

