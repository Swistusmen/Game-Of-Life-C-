#ifndef LOGIC_HPP_INCLUDED
#define LOGIC_HPP_INCLUDED



#endif // LOGIC_HPP_INCLUDED
#pragma once
#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <memory>
#include <vector>
#include <list>
#include <map>
#include <fstream>
#include <sstream>
#include <utility>
#define RAMKA 100
#define SKALAR 25
#define SRODKOWANIE 5
//rozmiar planszy do gry to 60* 60 p�l

template <typename T>// C++11
class Object
{
public:

    Object(T a,T b):x(a),y(b) {};
    T ret_x()
    {
        return x;
    };
    T ret_y()
    {
        return y;
    };
private:
    T x,y;
};

class DoubleTab
{
public:
    bool IsZero(int,int);
    void create(int);
    void Zero();
    void Set_value(int,int, bool);
    DoubleTab();
    int Get_size()
    {
        return SizeOfPlayground;
    };
    bool Sniff(int, int);
private:
    int SizeOfPlayground;
    bool**wsk;
};

class Playground
{
public:
    Playground();
    void LoadFromFileAndInitiate();//tak naprawde jest to konstruktor
    void update(sf::RenderWindow &,int );
    void Hunt();//sciaga elementy z wektora i przeszukuje otoczenie tego obiektu odsylajac delegacje dla kazdego
    //z obiektow
    //void FullFillTheValues(std::string& ,int );//zalazek dla inicjowanie planszy z menu
    void regenerate();
    void draw(sf::RenderWindow &);
    void Return_Previous_State();

    void Hunting();
private:
    DoubleTab plansza;
    sf::Sprite Cell;
    sf::Texture AliveCell;

    void HuntAndKill(int,int); //Dostaje pole z punktem na srodku, sprawdza czy elementy pola s� �ywe
    void EraseTheVector();//czysci wektor
    void RegenerateFromStack();//regeneruje tablice,  nirpotrzebne- relikt gameoflife8?
    int FindInt(std::string& );
    void Decompress(int,int,int,std::string &);//odczyt zaszyfrowanej inforamcji i ustawienie tablicy i wektora1 na wartosci

    std::vector<Object<int>> wektor1;
    std::vector<Object<int>> wektor2;
    bool VectorSwitcher=0;//jesli zero tzn ze wektor 1, zaczynam od pierwzego

    //Potrzebne do stepback
    std::list<Object<int>> lista;
   // const int limmiter=20;
    int counter=0;
    std::list<Object<int>>::iterator it=lista.begin();
    std::list<Object<int>>::reverse_iterator it2=lista.rbegin();
};


